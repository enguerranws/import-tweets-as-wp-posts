<?php
    
	// API Settings

    define('CONSUMER_KEY', get_option( 'tweets_to_posts_ck', '' ));
    define('CONSUMER_SECRET', get_option( 'tweets_to_posts_cs', '' ));
    define('ACCESS_TOKEN', get_option( 'tweets_to_posts_at', '' ));
    define('ACCESS_SECRET', get_option( 'tweets_to_posts_as', '' ));